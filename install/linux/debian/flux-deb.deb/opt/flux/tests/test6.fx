#import "standard.fx";

object myo1, myo2, myo3;

def main() -> int
{
	return 0;
};